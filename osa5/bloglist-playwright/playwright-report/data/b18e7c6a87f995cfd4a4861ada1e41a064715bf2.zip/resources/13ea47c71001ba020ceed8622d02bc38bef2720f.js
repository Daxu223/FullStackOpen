import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8a83d9c8"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=8a83d9c8"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Togglable = _s(forwardRef(_c = _s((props, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideChildComponent = { display: visible ? "none" : "" };
  const showChildComponent = { display: visible ? "" : "none" };
  const toggleVisibility = () => setVisible(!visible);
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideChildComponent, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: props.buttonLabel }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 42,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showChildComponent, children: [
      props.children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "Cancel" }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
        lineNumber: 47,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
      lineNumber: 45,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
Togglable.propTypes = {
  buttonLabel: PropTypes.string.isRequired
};
Togglable.displayName = "Togglable";
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Togglable.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxVQUFVQyxxQkFBcUJDLGtCQUFrQjtBQUMxRCxPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLFlBQVNDLEdBQUdILFdBQVVJLEtBQUFELEdBQUMsQ0FBQ0UsT0FBT0MsUUFBUTtBQUFBSCxLQUFBO0FBQzNDLFFBQU0sQ0FBQ0ksU0FBU0MsVUFBVSxJQUFJVixTQUFTLEtBQUs7QUFHNUMsUUFBTVcscUJBQXFCLEVBQUVDLFNBQVNILFVBQVUsU0FBUyxHQUFHO0FBRTVELFFBQU1JLHFCQUFxQixFQUFFRCxTQUFTSCxVQUFVLEtBQUssT0FBTztBQUU1RCxRQUFNSyxtQkFBbUJBLE1BQU1KLFdBQVcsQ0FBQ0QsT0FBTztBQUVsRFIsc0JBQW9CTyxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQ0xNO0FBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFFRCxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUFJLE9BQU9ILG9CQUNWLGlDQUFDLFlBQU8sU0FBU0csa0JBQW1CUCxnQkFBTVEsZUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRCxLQUR4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksT0FBT0Ysb0JBQ1ROO0FBQUFBLFlBQU1TO0FBQUFBLE1BQ1AsdUJBQUMsWUFBTyxTQUFTRixrQkFBa0Isc0JBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQUYzQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FTQTtBQUVKLEdBQUMsa0NBQUM7QUFBQUcsTUE1QkliO0FBOEJOQSxVQUFVYyxZQUFZO0FBQUEsRUFDcEJILGFBQWFaLFVBQVVnQixPQUFPQztBQUNoQztBQUVBaEIsVUFBVWlCLGNBQWM7QUFFeEIsZUFBZWpCO0FBQVMsSUFBQUUsSUFBQVc7QUFBQUssYUFBQWhCLElBQUE7QUFBQWdCLGFBQUFMLEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJmb3J3YXJkUmVmIiwiUHJvcFR5cGVzIiwiVG9nZ2xhYmxlIiwiX3MiLCJfYyIsInByb3BzIiwicmVmIiwidmlzaWJsZSIsInNldFZpc2libGUiLCJoaWRlQ2hpbGRDb21wb25lbnQiLCJkaXNwbGF5Iiwic2hvd0NoaWxkQ29tcG9uZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsImJ1dHRvbkxhYmVsIiwiY2hpbGRyZW4iLCJfYzIiLCJwcm9wVHlwZXMiLCJzdHJpbmciLCJpc1JlcXVpcmVkIiwiZGlzcGxheU5hbWUiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUb2dnbGFibGUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VJbXBlcmF0aXZlSGFuZGxlLCBmb3J3YXJkUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IFRvZ2dsYWJsZSA9IGZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgLy8gSGlkZXMgY29tcG9uZW50LCB3aGVuIHZpc2liaWxpdHkgc2V0IHRvIHRydWVcbiAgY29uc3QgaGlkZUNoaWxkQ29tcG9uZW50ID0geyBkaXNwbGF5OiB2aXNpYmxlID8gJ25vbmUnIDogJycgfVxuICAvLyBTaG93cyBjb21wb25lbnQsIHdoZW4gdmlzaWJpbGl0eSBzZXQgdG8gdHJ1ZVxuICBjb25zdCBzaG93Q2hpbGRDb21wb25lbnQgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XG4gIC8vIFVzZXMgdGhlIHN0YXRlIHRvIHRvZ2dsZSBpdCBvZmYsIGlmIG9uLCBhbmQgdGhlIG90aGVyIHdheSBhcm91bmRcbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHNldFZpc2libGUoIXZpc2libGUpXG5cbiAgdXNlSW1wZXJhdGl2ZUhhbmRsZShyZWYsICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9nZ2xlVmlzaWJpbGl0eVxuICAgIH1cbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2IHN0eWxlPXtoaWRlQ2hpbGRDb21wb25lbnR9PlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9Pntwcm9wcy5idXR0b25MYWJlbH08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IHN0eWxlPXtzaG93Q2hpbGRDb21wb25lbnR9PlxuICAgICAgICB7cHJvcHMuY2hpbGRyZW59XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dG9nZ2xlVmlzaWJpbGl0eX0+Q2FuY2VsPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxufSlcblxuVG9nZ2xhYmxlLnByb3BUeXBlcyA9IHtcbiAgYnV0dG9uTGFiZWw6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuXG5Ub2dnbGFibGUuZGlzcGxheU5hbWUgPSAnVG9nZ2xhYmxlJ1xuXG5leHBvcnQgZGVmYXVsdCBUb2dnbGFibGUiXSwiZmlsZSI6IkM6L1VzZXJzL3NhbXVrL0RvY3VtZW50cy9PaGplbG1vaW50aS9XZWIvRnVsbFN0YWNrT3Blbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL1RvZ2dsYWJsZS5qc3gifQ==