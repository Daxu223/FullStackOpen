import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Notification.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
const Notification = ({ message, type }) => {
  if (!message) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className: type, children: message }, void 0, false, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_c = Notification;
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Notification.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBTUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFOSixNQUFNQSxlQUFlQSxDQUFDLEVBQUVDLFNBQVNDLEtBQUssTUFBTTtBQUMxQyxNQUFJLENBQUNELFNBQVM7QUFDWixXQUFPO0FBQUEsRUFDVDtBQUVBLFNBQ0UsdUJBQUMsU0FBSSxXQUFXQyxNQUNiRCxxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDRSxLQVZLSDtBQVlOLGVBQWVBO0FBQVksSUFBQUc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIk5vdGlmaWNhdGlvbiIsIm1lc3NhZ2UiLCJ0eXBlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UsIHR5cGUgfSkgPT4ge1xuICBpZiAoIW1lc3NhZ2UpIHtcbiAgICByZXR1cm4gbnVsbFxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT17dHlwZX0+XG4gICAgICB7bWVzc2FnZX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6IkM6L1VzZXJzL3NhbXVrL0RvY3VtZW50cy9PaGplbG1vaW50aS9XZWIvRnVsbFN0YWNrT3Blbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gifQ==