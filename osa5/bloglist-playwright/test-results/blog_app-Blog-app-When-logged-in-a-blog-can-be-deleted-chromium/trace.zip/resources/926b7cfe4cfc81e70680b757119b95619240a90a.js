import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8a83d9c8"; const useState = __vite__cjsImport3_react["useState"];
const LoginForm = ({ loginFunction }) => {
  _s();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const formHandler = (event) => {
    event.preventDefault();
    loginFunction(username, password);
    setPassword("");
    setUsername("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: formHandler, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: username,
            "data-testid": "username",
            name: "username",
            onChange: ({ target }) => setUsername(target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
            lineNumber: 42,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "password",
            value: password,
            "data-testid": "password",
            name: "password",
            onChange: ({ target }) => setPassword(target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
            lineNumber: 52,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Login" }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
        lineNumber: 60,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx",
    lineNumber: 37,
    columnNumber: 5
  }, this);
};
_s(LoginForm, "wuQOK7xaXdVz4RMrZQhWbI751Oc=");
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/LoginForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxCTixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsWUFBWUEsQ0FBQyxFQUFFQyxjQUFjLE1BQU07QUFBQUMsS0FBQTtBQUN2QyxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSUwsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ00sVUFBVUMsV0FBVyxJQUFJUCxTQUFTLEVBQUU7QUFHM0MsUUFBTVEsY0FBY0EsQ0FBQ0MsVUFBVTtBQUM3QkEsVUFBTUMsZUFBZTtBQUNyQlIsa0JBQWNFLFVBQVVFLFFBQVE7QUFHaENDLGdCQUFZLEVBQUU7QUFDZEYsZ0JBQVksRUFBRTtBQUFBLEVBQ2hCO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekIsdUJBQUMsVUFBSyxVQUFVRyxhQUNkO0FBQUEsNkJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT0o7QUFBQUEsWUFDUCxlQUFZO0FBQUEsWUFDWixNQUFLO0FBQUEsWUFDTCxVQUFVLENBQUMsRUFBRU8sT0FBTyxNQUFNTixZQUFZTSxPQUFPQyxLQUFLO0FBQUE7QUFBQSxVQUxwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLc0Q7QUFBQSxXQVB4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU9OO0FBQUFBLFlBQ1AsZUFBWTtBQUFBLFlBQ1osTUFBSztBQUFBLFlBQ0wsVUFBVSxDQUFDLEVBQUVLLE9BQU8sTUFBTUosWUFBWUksT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS3NEO0FBQUEsV0FQeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBckI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsT0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQTtBQUVKO0FBQUNULEdBMUNLRixXQUFTO0FBQUFZLEtBQVRaO0FBNENOLGVBQWVBO0FBQVMsSUFBQVk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiTG9naW5Gb3JtIiwibG9naW5GdW5jdGlvbiIsIl9zIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJmb3JtSGFuZGxlciIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBMb2dpbkZvcm0gPSAoeyBsb2dpbkZ1bmN0aW9uIH0pID0+IHtcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcblxuICAvLyBUbyBsaWZ0IHN0YXRlIHVwLCB3ZSBuZWVkIGEgZnVuY3Rpb24gZnJvbSB0aGUgQXBwLmpzeFxuICBjb25zdCBmb3JtSGFuZGxlciA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBsb2dpbkZ1bmN0aW9uKHVzZXJuYW1lLCBwYXNzd29yZClcblxuICAgIC8vIFJlc2V0IGZvcm1zXG4gICAgc2V0UGFzc3dvcmQoJycpXG4gICAgc2V0VXNlcm5hbWUoJycpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtmb3JtSGFuZGxlcn0+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ1c2VybmFtZVwiXG4gICAgICAgICAgICBuYW1lPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgcGFzc3dvcmRcbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICBkYXRhLXRlc3RpZD1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkxvZ2luPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgTG9naW5Gb3JtIl0sImZpbGUiOiJDOi9Vc2Vycy9zYW11ay9Eb2N1bWVudHMvT2hqZWxtb2ludGkvV2ViL0Z1bGxTdGFja09wZW4vb3NhNS9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9Mb2dpbkZvcm0uanN4In0=