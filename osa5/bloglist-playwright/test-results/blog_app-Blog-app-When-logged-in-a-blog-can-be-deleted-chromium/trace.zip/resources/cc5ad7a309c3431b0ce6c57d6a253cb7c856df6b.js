import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8a83d9c8"; const useState = __vite__cjsImport3_react["useState"];
const Blog = ({ blog, user, onLike, onDelete }) => {
  _s();
  const [detailsVisible, setVisible] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    paddingBottom: 10,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const toggleVisibility = () => {
    setVisible(!detailsVisible);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { "data-testid": "blog-title-author", children: [
        blog.title,
        " ",
        blog.author
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "detailsButton",
          style: { marginLeft: 4 },
          onClick: toggleVisibility,
          children: detailsVisible ? "hide" : "view"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 52,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    detailsVisible && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("div", { children: blog.url }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 62,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "likes ",
        blog.likes,
        /* @__PURE__ */ jsxDEV(LikeButton, { blog, onLike }, void 0, false, {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
          lineNumber: 64,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 63,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: blog.user.name }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(DeleteButton, { blog, onDelete, user }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 67,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 61,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 47,
    columnNumber: 5
  }, this);
};
_s(Blog, "vVPDJ6jhDIhB0FuPkG8pZsjLt6U=");
_c = Blog;
const LikeButton = ({ blog, onLike }) => {
  const likeFunction = async (blogObject) => {
    onLike(blogObject);
  };
  return /* @__PURE__ */ jsxDEV("button", { style: { marginLeft: 3 }, onClick: () => likeFunction(blog), children: "like" }, void 0, false, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
};
_c2 = LikeButton;
const DeleteButton = ({ blog, onDelete, user }) => {
  const deleteButtonStyle = {
    background: "linear-gradient(90deg, rgba(253,29,29,1) 17%, rgba(252,176,69,1) 100%)",
    borderRadius: "30px",
    color: "white"
  };
  const blogOwnerUsername = blog.user.username;
  const currentUsername = user ? user.username : null;
  const deleteFunction = async (blogId) => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}?`)) {
      onDelete(blogId);
    }
  };
  if (blogOwnerUsername === currentUsername)
    return /* @__PURE__ */ jsxDEV("button", { style: deleteButtonStyle, onClick: () => deleteFunction(blog.id), children: "remove" }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 114,
      columnNumber: 5
    }, this);
  return null;
};
_c3 = DeleteButton;
export default Blog;
var _c, _c2, _c3;
$RefreshReg$(_c, "Blog");
$RefreshReg$(_c2, "LikeButton");
$RefreshReg$(_c3, "DeleteButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/Blog.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCUixTQUFTQSxnQkFBZ0I7QUFJekIsTUFBTUMsT0FBT0EsQ0FBQyxFQUFFQyxNQUFNQyxNQUFNQyxRQUFRQyxTQUFTLE1BQU07QUFBQUMsS0FBQTtBQU9qRCxRQUFNLENBQUNDLGdCQUFnQkMsVUFBVSxJQUFJUixTQUFTLEtBQUs7QUFFbkQsUUFBTVMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxJQUNmQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLG1CQUFtQkEsTUFBTTtBQUM3QlIsZUFBVyxDQUFDRCxjQUFjO0FBQUEsRUFDNUI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUFPLE9BQU9FLFdBQzNCO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUssZUFBWSxxQkFDZlA7QUFBQUEsYUFBS2U7QUFBQUEsUUFBTTtBQUFBLFFBQUVmLEtBQUtnQjtBQUFBQSxXQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixPQUFPLEVBQUVDLFlBQVksRUFBRTtBQUFBLFVBQ3ZCLFNBQVNIO0FBQUFBLFVBQ1JULDJCQUFpQixTQUFTO0FBQUE7QUFBQSxRQUo3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFLQTtBQUFBLFNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQ0Esa0JBQ0MsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFNBQUtMLGVBQUtrQixPQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsU0FBSTtBQUFBO0FBQUEsUUFBT2xCLEtBQUttQjtBQUFBQSxRQUNmLHVCQUFDLGNBQVcsTUFBWSxVQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsV0FEekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFLbkIsZUFBS0MsS0FBS21CLFFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUI7QUFBQSxNQUNyQix1QkFBQyxnQkFBYSxNQUFZLFVBQW9CLFFBQTlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUQ7QUFBQSxTQU4zRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxPQXJCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBQ2hCLEdBaERLTCxNQUFJO0FBQUFzQixLQUFKdEI7QUFrRE4sTUFBTXVCLGFBQWFBLENBQUMsRUFBRXRCLE1BQU1FLE9BQU8sTUFBTTtBQUN2QyxRQUFNcUIsZUFBZSxPQUFPQyxlQUFlO0FBQ3pDdEIsV0FBT3NCLFVBQVU7QUFBQSxFQUNuQjtBQUVBLFNBQ0UsdUJBQUMsWUFBTyxPQUFPLEVBQUVQLFlBQVksRUFBRSxHQUFHLFNBQVMsTUFBTU0sYUFBYXZCLElBQUksR0FBRSxvQkFBcEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ3lCLE1BVktIO0FBWU4sTUFBTUksZUFBZUEsQ0FBQyxFQUFFMUIsTUFBTUcsVUFBVUYsS0FBSyxNQUFNO0FBQ2pELFFBQU0wQixvQkFBb0I7QUFBQSxJQUN4QkMsWUFBWTtBQUFBLElBQ1pDLGNBQWM7QUFBQSxJQUNkQyxPQUFPO0FBQUEsRUFDVDtBQUdBLFFBQU1DLG9CQUFvQi9CLEtBQUtDLEtBQUsrQjtBQUtwQyxRQUFNQyxrQkFBa0JoQyxPQUFPQSxLQUFLK0IsV0FBVztBQUkvQyxRQUFNRSxpQkFBaUIsT0FBT0MsV0FBVztBQUN2QyxRQUFJQyxPQUFPQyxRQUFRLGVBQWVyQyxLQUFLZSxLQUFLLE9BQU9mLEtBQUtnQixNQUFNLEdBQUcsR0FBRztBQUNsRWIsZUFBU2dDLE1BQU07QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFLQSxNQUFJSixzQkFBc0JFO0FBQ3hCLFdBQ0UsdUJBQUMsWUFBTyxPQUFPTixtQkFBbUIsU0FBUyxNQUFNTyxlQUFlbEMsS0FBS3NDLEVBQUUsR0FBRSxzQkFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBR0osU0FBTztBQUNUO0FBQUNDLE1BbENLYjtBQW9DTixlQUFlM0I7QUFBSSxJQUFBc0IsSUFBQUksS0FBQWM7QUFBQUMsYUFBQW5CLElBQUE7QUFBQW1CLGFBQUFmLEtBQUE7QUFBQWUsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZyIsImJsb2ciLCJ1c2VyIiwib25MaWtlIiwib25EZWxldGUiLCJfcyIsImRldGFpbHNWaXNpYmxlIiwic2V0VmlzaWJsZSIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsInBhZGRpbmdCb3R0b20iLCJib3JkZXIiLCJib3JkZXJXaWR0aCIsIm1hcmdpbkJvdHRvbSIsInRvZ2dsZVZpc2liaWxpdHkiLCJ0aXRsZSIsImF1dGhvciIsIm1hcmdpbkxlZnQiLCJ1cmwiLCJsaWtlcyIsIm5hbWUiLCJfYyIsIkxpa2VCdXR0b24iLCJsaWtlRnVuY3Rpb24iLCJibG9nT2JqZWN0IiwiX2MyIiwiRGVsZXRlQnV0dG9uIiwiZGVsZXRlQnV0dG9uU3R5bGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyUmFkaXVzIiwiY29sb3IiLCJibG9nT3duZXJVc2VybmFtZSIsInVzZXJuYW1lIiwiY3VycmVudFVzZXJuYW1lIiwiZGVsZXRlRnVuY3Rpb24iLCJibG9nSWQiLCJ3aW5kb3ciLCJjb25maXJtIiwiaWQiLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG4vLyBUbyBub3RlOiBibG9ncyBhcmUgcmVuZGVyZWQgaW5kaXZpZHVhbGx5XG4vLyBUaGlzIG1lYW5zIHRoZSBzdGF0ZSBvZiBhbGwgYmxvZ3MgYXJlIGFsc28gaW5kaXZpZHVhbFxuY29uc3QgQmxvZyA9ICh7IGJsb2csIHVzZXIsIG9uTGlrZSwgb25EZWxldGUgfSkgPT4ge1xuXG4gIC8vIEl0IHdvdWxkIGJlIGJldHRlciB0byBkZWZpbmUgYSBzdGF0ZSBmb3IgdGhpcyBibG9nLFxuICAvLyB3aGV0aGVyIGl0IGlzIHZpc2libGUgb3Igbm90LiBJZiB0aGUgY29udHJvbGxpbmcgYnV0dG9uIGlzIHByZXNzZWRcbiAgLy8gdGhlIHN0YXRlIGlzIHNldCBmcm9tIG5vbi12aXNpYmxlIHRvIHZpc2libGUuXG4gIC8vIEVhcmxpZXIgSSB0cmllZCB0byB1c2UgVG9nZ2xhYmxlIGJ1dCBpdCB3YXMgbm90IGNvbXBsZXRlbHkgc3VpdGFibGVcbiAgLy8gZm9yIHRoaXMgdXNlIGNhc2Ugc2NlbmFyaW8uXG4gIGNvbnN0IFtkZXRhaWxzVmlzaWJsZSwgc2V0VmlzaWJsZV0gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBibG9nU3R5bGUgPSB7XG4gICAgcGFkZGluZ1RvcDogMTAsXG4gICAgcGFkZGluZ0xlZnQ6IDIsXG4gICAgcGFkZGluZ0JvdHRvbTogMTAsXG4gICAgYm9yZGVyOiAnc29saWQnLFxuICAgIGJvcmRlcldpZHRoOiAxLFxuICAgIG1hcmdpbkJvdHRvbTogNVxuICB9XG5cbiAgY29uc3QgdG9nZ2xlVmlzaWJpbGl0eSA9ICgpID0+IHtcbiAgICBzZXRWaXNpYmxlKCFkZXRhaWxzVmlzaWJsZSlcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9J2Jsb2cnIHN0eWxlPXtibG9nU3R5bGV9PlxuICAgICAgPGRpdj5cbiAgICAgICAgPHNwYW4gZGF0YS10ZXN0aWQ9XCJibG9nLXRpdGxlLWF1dGhvclwiPlxuICAgICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIGNsYXNzTmFtZT1cImRldGFpbHNCdXR0b25cIlxuICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDQgfX1cbiAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT5cbiAgICAgICAgICB7ZGV0YWlsc1Zpc2libGUgPyAnaGlkZScgOiAndmlldycgfVxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7ZGV0YWlsc1Zpc2libGUgJiYgKFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXY+e2Jsb2cudXJsfTwvZGl2PlxuICAgICAgICAgIDxkaXY+bGlrZXMge2Jsb2cubGlrZXN9XG4gICAgICAgICAgICA8TGlrZUJ1dHRvbiBibG9nPXtibG9nfSBvbkxpa2U9e29uTGlrZX0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PntibG9nLnVzZXIubmFtZX08L2Rpdj5cbiAgICAgICAgICA8RGVsZXRlQnV0dG9uIGJsb2c9e2Jsb2d9IG9uRGVsZXRlPXtvbkRlbGV0ZX0gdXNlcj17dXNlcn0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmNvbnN0IExpa2VCdXR0b24gPSAoeyBibG9nLCBvbkxpa2UgfSkgPT4ge1xuICBjb25zdCBsaWtlRnVuY3Rpb24gPSBhc3luYyAoYmxvZ09iamVjdCkgPT4ge1xuICAgIG9uTGlrZShibG9nT2JqZWN0KVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMgfX0gb25DbGljaz17KCkgPT4gbGlrZUZ1bmN0aW9uKGJsb2cpfT5cbiAgICAgIGxpa2VcbiAgICA8L2J1dHRvbj5cbiAgKVxufVxuXG5jb25zdCBEZWxldGVCdXR0b24gPSAoeyBibG9nLCBvbkRlbGV0ZSwgdXNlciB9KSA9PiB7XG4gIGNvbnN0IGRlbGV0ZUJ1dHRvblN0eWxlID0ge1xuICAgIGJhY2tncm91bmQ6ICdsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHJnYmEoMjUzLDI5LDI5LDEpIDE3JSwgcmdiYSgyNTIsMTc2LDY5LDEpIDEwMCUpJyxcbiAgICBib3JkZXJSYWRpdXM6ICczMHB4JyxcbiAgICBjb2xvcjogJ3doaXRlJ1xuICB9XG5cbiAgLy8gR2V0IHRoZSBvd25lciBpZCBvZiB0aGUgYmxvZyBhbmQgdGhlIGN1cnJlbnQgdXNlciBmcm9tIHRoZSBBcHBcbiAgY29uc3QgYmxvZ093bmVyVXNlcm5hbWUgPSBibG9nLnVzZXIudXNlcm5hbWVcblxuICAvLyBOb3RpY2VkIGEgcHJvYmxlbSB3aGVyZSBpZiB0aGUgdXNlciBpcyBub3QgbG9nZ2VkIGluXG4gIC8vIEFuZCBpbiBmb3IgZXhhbXBsZSB0ZXN0cywgd2Ugd2FudCB0byBqdXN0IHRlc3QgdGhlIGJsb2cgc3RhdGVcbiAgLy8gSXQgY3Jhc2hlcyB0aGUgYXBwbGljYXRpb24sIHNvIGl0IHdhcyBmaXhlZCB3aXRoIGEgbnVsbCBjaGVjay5cbiAgY29uc3QgY3VycmVudFVzZXJuYW1lID0gdXNlciA/IHVzZXIudXNlcm5hbWUgOiBudWxsXG5cbiAgLy8gSGVyZSBzaG91bGQgZXhpc3Qgc29tZSBmdW5jdGlvbmFsaXR5IHRvIGNoZWNrIGlmIHRoZSB1c2VySWQgZnJvbSB0aGUgYmxvZ1xuICAvLyBpcyB0aGUgc2FtZSBhcyB0aGUgcmVxdWVzdGluZyB1c2VyLlxuICBjb25zdCBkZWxldGVGdW5jdGlvbiA9IGFzeW5jIChibG9nSWQpID0+IHtcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nICR7YmxvZy50aXRsZX0gYnkgJHtibG9nLmF1dGhvcn0/YCkpIHtcbiAgICAgIG9uRGVsZXRlKGJsb2dJZClcbiAgICB9XG4gIH1cblxuICAvLyBTaG93IHRoZSBkZWxldGUgYnV0dG9uIGlmIHRoZSB1c2VyIGlkIGlzIGNvbnRhaW5lZCB3aXRoaW4gdGhlIGJsb2dzXG4gIC8vIEluaXRpYWxseSwgSSB3YW50ZWQgdG8gdXNlIGlkcy4gVGhlIGRpZmZpY3VsdHkgaXMgdGhhdCB0aGUgdXNlciBzdGF0ZVxuICAvLyBoYXMgdG9rZW4sIG5hbWUgYW5kIHVzZXIgYW5kIG5vIGlkLlxuICBpZiAoYmxvZ093bmVyVXNlcm5hbWUgPT09IGN1cnJlbnRVc2VybmFtZSlcbiAgICByZXR1cm4gKFxuICAgICAgPGJ1dHRvbiBzdHlsZT17ZGVsZXRlQnV0dG9uU3R5bGV9IG9uQ2xpY2s9eygpID0+IGRlbGV0ZUZ1bmN0aW9uKGJsb2cuaWQpfT5cbiAgICAgICAgcmVtb3ZlXG4gICAgICA8L2J1dHRvbj5cbiAgICApXG5cbiAgcmV0dXJuIG51bGxcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiQzovVXNlcnMvc2FtdWsvRG9jdW1lbnRzL09oamVsbW9pbnRpL1dlYi9GdWxsU3RhY2tPcGVuL29zYTUvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==