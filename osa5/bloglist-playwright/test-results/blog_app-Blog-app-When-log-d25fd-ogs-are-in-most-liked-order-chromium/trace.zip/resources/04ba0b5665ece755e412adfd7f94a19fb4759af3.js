import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8a83d9c8"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({ createBlog }) => {
  _s();
  const [blog, setBlog] = useState(
    {
      author: "",
      title: "",
      url: ""
    }
  );
  const formHandler = (event) => {
    event.preventDefault();
    createBlog(blog);
    setBlog({ title: "", author: "", url: "" });
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: formHandler, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Title:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blog.title,
          name: "title",
          "data-testid": "title",
          placeholder: "title",
          onChange: ({ target }) => setBlog({ ...blog, title: target.value })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 49,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Author:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blog.author,
          name: "author",
          "data-testid": "author",
          placeholder: "author",
          onChange: ({ target }) => setBlog({ ...blog, author: target.value })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 61,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      "Url:",
      /* @__PURE__ */ jsxDEV(
        "input",
        {
          type: "text",
          value: blog.url,
          name: "url",
          "data-testid": "url",
          placeholder: "url",
          onChange: ({ target }) => setBlog({ ...blog, url: target.value })
        },
        void 0,
        false,
        {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
          lineNumber: 73,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 71,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Create" }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
      lineNumber: 82,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx",
    lineNumber: 46,
    columnNumber: 5
  }, this);
};
_s(BlogForm, "He7qwwjlcsY5srK5nHLJXLpyL+k=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/components/BlogForm.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJROzs7Ozs7Ozs7Ozs7Ozs7OztBQTdCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQyxFQUFFQyxXQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNuQyxRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSUw7QUFBQUEsSUFDdEI7QUFBQSxNQUNFTSxRQUFRO0FBQUEsTUFDUkMsT0FBTztBQUFBLE1BQ1BDLEtBQUs7QUFBQSxJQUNQO0FBQUEsRUFDRjtBQU1BLFFBQU1DLGNBQWNBLENBQUNDLFVBQVU7QUFDN0JBLFVBQU1DLGVBQWU7QUFHckJULGVBQVdFLElBQUk7QUFHZkMsWUFBUSxFQUFFRSxPQUFPLElBQUlELFFBQVEsSUFBSUUsS0FBSyxHQUFHLENBQUM7QUFBQSxFQUM1QztBQUVBLFNBQ0UsdUJBQUMsVUFBSyxVQUFVQyxhQUNkO0FBQUEsMkJBQUMsU0FBRztBQUFBO0FBQUEsTUFFRjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsTUFBSztBQUFBLFVBQ0wsT0FBT0wsS0FBS0c7QUFBQUEsVUFDWixNQUFLO0FBQUEsVUFDTCxlQUFZO0FBQUEsVUFDWixhQUFZO0FBQUEsVUFDWixVQUFVLENBQUMsRUFBRUssT0FBTyxNQUFNUCxRQUFRLEVBQUUsR0FBR0QsTUFBTUcsT0FBT0ssT0FBT0MsTUFBTSxDQUFDO0FBQUE7QUFBQSxRQU5wRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNc0U7QUFBQSxTQVJ4RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxJQUVBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLE1BRUY7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLE1BQUs7QUFBQSxVQUNMLE9BQU9ULEtBQUtFO0FBQUFBLFVBQ1osTUFBSztBQUFBLFVBQ0wsZUFBWTtBQUFBLFVBQ1osYUFBWTtBQUFBLFVBQ1osVUFBVSxDQUFDLEVBQUVNLE9BQU8sTUFBTVAsUUFBUSxFQUFFLEdBQUdELE1BQU1FLFFBQVFNLE9BQU9DLE1BQU0sQ0FBQztBQUFBO0FBQUEsUUFOckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BTXVFO0FBQUEsU0FSekU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFFQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxNQUVGO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxNQUFLO0FBQUEsVUFDTCxPQUFPVCxLQUFLSTtBQUFBQSxVQUNaLE1BQUs7QUFBQSxVQUNMLGVBQVk7QUFBQSxVQUNaLGFBQVk7QUFBQSxVQUNaLFVBQVUsQ0FBQyxFQUFFSSxPQUFPLE1BQU1QLFFBQVEsRUFBRSxHQUFHRCxNQUFNSSxLQUFLSSxPQUFPQyxNQUFNLENBQUM7QUFBQTtBQUFBLFFBTmxFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU1vRTtBQUFBLFNBUnRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQXBDOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFDQTtBQUVKO0FBQUNWLEdBL0RLRixVQUFRO0FBQUFhLEtBQVJiO0FBaUVOLGVBQWVBO0FBQVEsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJibG9nIiwic2V0QmxvZyIsImF1dGhvciIsInRpdGxlIiwidXJsIiwiZm9ybUhhbmRsZXIiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwidmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBCbG9nRm9ybSA9ICh7IGNyZWF0ZUJsb2cgfSkgPT4ge1xuICBjb25zdCBbYmxvZywgc2V0QmxvZ10gPSB1c2VTdGF0ZShcbiAgICB7XG4gICAgICBhdXRob3I6ICcnLFxuICAgICAgdGl0bGU6ICcnLFxuICAgICAgdXJsOiAnJ1xuICAgIH1cbiAgKVxuXG4gIC8vIFVzZXMgdGhlIGZ1bmN0aW9uYWxpdHkgb2YgYmxvZyBhZGRpbmcgZGVmaW5lZCBpbiBBcHAuanN4XG4gIC8vIFRoaXMgb25seSBoYW5kbGVzIHRoZSBmb3JtIG9wZXJhdGlvbjpcbiAgLy8gcmVzZXR0aW5nIHRoZSBmb3JtLCB1c2luZyBmdW5jdGlvbiBwcm9wcy5hZGRCbG9nIChmcm9tIEFwcC5qc3gpXG4gIC8vIHV0aWxpemluZyB0aGUgc3RhdGUgb2YgdGhlIGZvcm0geyBhdXRob3I6ICcnLCB0aXRsZTogJycsIHVybDogJyd9XG4gIGNvbnN0IGZvcm1IYW5kbGVyID0gKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuXG4gICAgLy8gVXNlIHBhc3NlZCBmdW5jdGlvbmFsaXR5XG4gICAgY3JlYXRlQmxvZyhibG9nKVxuXG4gICAgLy8gUmVzZXQgZm9ybVxuICAgIHNldEJsb2coeyB0aXRsZTogJycsIGF1dGhvcjogJycsIHVybDogJycgfSlcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2Zvcm1IYW5kbGVyfT5cbiAgICAgIDxkaXY+XG4gICAgICBUaXRsZTpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXtibG9nLnRpdGxlfVxuICAgICAgICAgIG5hbWU9XCJ0aXRsZVwiXG4gICAgICAgICAgZGF0YS10ZXN0aWQ9XCJ0aXRsZVwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJ0aXRsZVwiXG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRCbG9nKHsgLi4uYmxvZywgdGl0bGU6IHRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2PlxuICAgICAgQXV0aG9yOlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgdmFsdWU9e2Jsb2cuYXV0aG9yfVxuICAgICAgICAgIG5hbWU9XCJhdXRob3JcIlxuICAgICAgICAgIGRhdGEtdGVzdGlkPVwiYXV0aG9yXCJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImF1dGhvclwiXG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRCbG9nKHsgLi4uYmxvZywgYXV0aG9yOiB0YXJnZXQudmFsdWUgfSl9XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdj5cbiAgICAgIFVybDpcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgIHZhbHVlPXtibG9nLnVybH1cbiAgICAgICAgICBuYW1lPVwidXJsXCJcbiAgICAgICAgICBkYXRhLXRlc3RpZD1cInVybFwiXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJ1cmxcIlxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0QmxvZyh7IC4uLmJsb2csIHVybDogdGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5DcmVhdGU8L2J1dHRvbj5cbiAgICA8L2Zvcm0+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6IkM6L1VzZXJzL3NhbXVrL0RvY3VtZW50cy9PaGplbG1vaW50aS9XZWIvRnVsbFN0YWNrT3Blbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9