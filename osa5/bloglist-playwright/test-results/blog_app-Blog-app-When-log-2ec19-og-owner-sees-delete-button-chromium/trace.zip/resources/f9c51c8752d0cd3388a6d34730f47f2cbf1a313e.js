import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=8a83d9c8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = RefreshRuntime.getRefreshReg("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx");
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=8a83d9c8"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx?t=1750177011487";
import Notification from "/src/components/Notification.jsx";
import Togglable from "/src/components/Togglable.jsx";
import BlogForm from "/src/components/BlogForm.jsx?t=1750171190936";
import LoginForm from "/src/components/LoginForm.jsx?t=1750170578713";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState({ message: "", type: null });
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const blogFormRef = useRef(null);
  useEffect(() => {
    if (user) {
      blogService.getAll().then((blogs2) => {
        setBlogs(blogs2.sort((a, b) => b.likes - a.likes));
      });
    } else {
      setBlogs([]);
    }
  }, [user]);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("blogUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (username2, password2) => {
    try {
      const user2 = await loginService.login({
        username: username2,
        password: password2
      });
      window.localStorage.setItem(
        "blogUser",
        JSON.stringify(user2)
      );
      blogService.setToken(user2.token);
      setUser(user2);
    } catch (exception) {
      setMessage({ message: "Wrong credentials", type: "error" });
      setTimeout(() => {
        setMessage({ message: "", type: null });
      }, 5e3);
    }
  };
  const addBlog = async (blogObject) => {
    try {
      blogFormRef.current.toggleVisibility();
      const returnedBlog = await blogService.create(blogObject);
      const updatedBlogWithUser = {
        ...returnedBlog,
        user
        // Use state in the hook
      };
      const updatedBlogs = blogs.concat(updatedBlogWithUser);
      setBlogs(updatedBlogs.sort((a, b) => b.likes - a.likes));
      setMessage({ message: `A new blog called ${blogObject.title} added!`, type: "success" });
      setTimeout(() => {
        setMessage({ message: "", type: null });
      }, 5e3);
    } catch (exception) {
      setMessage({ message: "Check input fields", type: "error" });
      setTimeout(() => {
        setMessage({ message: "", type: null });
      }, 5e3);
    }
  };
  const blogLiked = async (blogObject) => {
    try {
      const likedBlog = {
        id: blogObject.id,
        title: blogObject.title,
        author: blogObject.author,
        url: blogObject.url,
        likes: blogObject.likes + 1,
        user: blogObject.user.id
      };
      const updatedBlog = await blogService.update(likedBlog);
      const updatedBlogWithUser = {
        ...updatedBlog,
        user: blogObject.user
      };
      const updatedBlogs = blogs.map((blog) => blog.id !== updatedBlog.id ? blog : updatedBlogWithUser);
      setBlogs(updatedBlogs.sort((a, b) => b.likes - a.likes));
    } catch (error) {
      console.log("Error liking blog: ", error);
    }
  };
  const blogDeleted = async (id) => {
    try {
      await blogService.deleteItem(id);
      const filteredBlogs = blogs.filter((blog) => blog.id !== id);
      setBlogs(filteredBlogs.sort((a, b) => b.likes - a.likes));
    } catch (error) {
      console.log("Error deleting blog: ", error);
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 161,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "text",
            value: username,
            name: "username",
            onChange: ({ target }) => setUsername(target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
            lineNumber: 165,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV(
          "input",
          {
            type: "password",
            value: password,
            name: "password",
            onChange: ({ target }) => setPassword(target.value)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
            lineNumber: 174,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 172,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Login" }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 181,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 162,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 160,
    columnNumber: 3
  }, this);
  const removeUserFromLocalStorage = () => {
    window.localStorage.removeItem("blogUser");
    setUser(null);
  };
  const userIsLoggedIn = (user2) => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      user2.name,
      " logged in ",
      /* @__PURE__ */ jsxDEV("button", { onClick: () => removeUserFromLocalStorage(), children: "Logout" }, void 0, false, {
        fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
        lineNumber: 199,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 197,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 203,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Create a new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 206,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 205,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 209,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogs.map(
      (blog) => /* @__PURE__ */ jsxDEV(
        Blog,
        {
          blog,
          user: user2,
          onLike: blogLiked,
          onDelete: blogDeleted
        },
        blog.id,
        false,
        {
          fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
          lineNumber: 213,
          columnNumber: 7
        },
        this
      )
    ) }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 211,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 196,
    columnNumber: 3
  }, this);
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 228,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: message.message, type: message.type }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 229,
      columnNumber: 7
    }, this),
    !user && /* @__PURE__ */ jsxDEV(LoginForm, { loginFunction: handleLogin }, void 0, false, {
      fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
      lineNumber: 231,
      columnNumber: 17
    }, this),
    user && userIsLoggedIn(user)
  ] }, void 0, true, {
    fileName: "C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx",
    lineNumber: 227,
    columnNumber: 5
  }, this);
};
_s(App, "9sqe6D/HdYs9V2g3lA5PirwH6sM=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/samuk/Documents/Ohjelmointi/Web/FullStackOpen/osa5/bloglist-frontend/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNklNOzs7Ozs7Ozs7Ozs7Ozs7OztBQTdJTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJYixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYyxVQUFVQyxXQUFXLElBQUlmLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNnQixTQUFTQyxVQUFVLElBQUlqQixTQUFTLEVBQUVnQixTQUFTLElBQUlFLE1BQU0sS0FBSyxDQUFDO0FBQ2xFLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJcEIsU0FBUyxFQUFFO0FBQzNDLFFBQU0sQ0FBQ3FCLE1BQU1DLE9BQU8sSUFBSXRCLFNBQVMsSUFBSTtBQUVyQyxRQUFNdUIsY0FBY3JCLE9BQU8sSUFBSTtBQUkvQkQsWUFBVSxNQUFNO0FBQ2QsUUFBSW9CLE1BQU07QUFDUmIsa0JBQVlnQixPQUFPLEVBQUVDLEtBQUssQ0FBQWIsV0FBUztBQUNqQ0MsaUJBQVNELE9BQU1jLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxDQUFDO0FBQUEsTUFDbEQsQ0FBQztBQUFBLElBQ0gsT0FBTztBQUNMaEIsZUFBUyxFQUFFO0FBQUEsSUFDYjtBQUFBLEVBQ0YsR0FBRyxDQUFDUSxJQUFJLENBQUM7QUFHVHBCLFlBQVUsTUFBTTtBQUNkLFVBQU02QixpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsVUFBVTtBQUM3RCxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVQsUUFBT2EsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1IsY0FBUUQsS0FBSTtBQUNaYixrQkFBWTRCLFNBQVNmLE1BQUtnQixLQUFLO0FBQUEsSUFDakM7QUFBQSxFQUNGLEdBQUcsRUFBRTtBQUVMLFFBQU1DLGNBQWMsT0FBT3hCLFdBQVVLLGNBQWE7QUFDaEQsUUFBSTtBQUNGLFlBQU1FLFFBQU8sTUFBTVosYUFBYThCLE1BQU07QUFBQSxRQUNwQ3pCO0FBQUFBLFFBQVVLO0FBQUFBLE1BQ1osQ0FBQztBQUVEWSxhQUFPQyxhQUFhUTtBQUFBQSxRQUNsQjtBQUFBLFFBQVlOLEtBQUtPLFVBQVVwQixLQUFJO0FBQUEsTUFDakM7QUFHQWIsa0JBQVk0QixTQUFTZixNQUFLZ0IsS0FBSztBQUMvQmYsY0FBUUQsS0FBSTtBQUFBLElBRWQsU0FBU3FCLFdBQVc7QUFDbEJ6QixpQkFBVyxFQUFFRCxTQUFTLHFCQUFxQkUsTUFBTSxRQUFRLENBQUM7QUFDMUR5QixpQkFBVyxNQUFNO0FBQ2YxQixtQkFBVyxFQUFFRCxTQUFTLElBQUlFLE1BQU0sS0FBSyxDQUFDO0FBQUEsTUFDeEMsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMEIsVUFBVSxPQUFPQyxlQUFlO0FBQ3BDLFFBQUk7QUFDRnRCLGtCQUFZdUIsUUFBUUMsaUJBQWlCO0FBRXJDLFlBQU1DLGVBQWUsTUFBTXhDLFlBQVl5QyxPQUFPSixVQUFVO0FBS3hELFlBQU1LLHNCQUFzQjtBQUFBLFFBQzFCLEdBQUdGO0FBQUFBLFFBQ0gzQjtBQUFBQTtBQUFBQSxNQUNGO0FBR0EsWUFBTThCLGVBQWV2QyxNQUFNd0MsT0FBT0YsbUJBQW1CO0FBQ3JEckMsZUFBU3NDLGFBQWF6QixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUssQ0FBQztBQUd2RFosaUJBQVcsRUFBRUQsU0FBUyxxQkFBcUI2QixXQUFXUSxLQUFLLFdBQVduQyxNQUFNLFVBQVUsQ0FBQztBQUd2RnlCLGlCQUFXLE1BQU07QUFDZjFCLG1CQUFXLEVBQUVELFNBQVMsSUFBSUUsTUFBTSxLQUFLLENBQUM7QUFBQSxNQUN4QyxHQUFHLEdBQUk7QUFBQSxJQUNULFNBQVN3QixXQUFXO0FBQ2xCekIsaUJBQVcsRUFBRUQsU0FBUyxzQkFBc0JFLE1BQU0sUUFBUSxDQUFDO0FBQzNEeUIsaUJBQVcsTUFBTTtBQUNmMUIsbUJBQVcsRUFBRUQsU0FBUyxJQUFJRSxNQUFNLEtBQUssQ0FBQztBQUFBLE1BQ3hDLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTW9DLFlBQVksT0FBT1QsZUFBZTtBQUN0QyxRQUFJO0FBQ0YsWUFBTVUsWUFBWTtBQUFBLFFBQ2hCQyxJQUFJWCxXQUFXVztBQUFBQSxRQUNmSCxPQUFPUixXQUFXUTtBQUFBQSxRQUNsQkksUUFBUVosV0FBV1k7QUFBQUEsUUFDbkJDLEtBQUtiLFdBQVdhO0FBQUFBLFFBQ2hCN0IsT0FBT2dCLFdBQVdoQixRQUFRO0FBQUEsUUFDMUJSLE1BQU13QixXQUFXeEIsS0FBS21DO0FBQUFBLE1BQ3hCO0FBR0EsWUFBTUcsY0FBYyxNQUFNbkQsWUFBWW9ELE9BQU9MLFNBQVM7QUFJdEQsWUFBTUwsc0JBQXNCO0FBQUEsUUFDMUIsR0FBR1M7QUFBQUEsUUFDSHRDLE1BQU13QixXQUFXeEI7QUFBQUEsTUFDbkI7QUFPQSxZQUFNOEIsZUFBZXZDLE1BQU1pRCxJQUFJLENBQUFDLFNBQVFBLEtBQUtOLE9BQU9HLFlBQVlILEtBQUtNLE9BQU9aLG1CQUFtQjtBQUM5RnJDLGVBQVNzQyxhQUFhekIsS0FBSyxDQUFDQyxHQUFHQyxNQUFNQSxFQUFFQyxRQUFRRixFQUFFRSxLQUFLLENBQUM7QUFBQSxJQUN6RCxTQUFTa0MsT0FBTztBQUNkQyxjQUFRQyxJQUFJLHVCQUF1QkYsS0FBSztBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUVBLFFBQU1HLGNBQWMsT0FBT1YsT0FBTztBQUNoQyxRQUFJO0FBQ0YsWUFBTWhELFlBQVkyRCxXQUFXWCxFQUFFO0FBQy9CLFlBQU1ZLGdCQUFnQnhELE1BQU15RCxPQUFPLENBQUFQLFNBQVFBLEtBQUtOLE9BQU9BLEVBQUU7QUFDekQzQyxlQUFTdUQsY0FBYzFDLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSyxDQUFDO0FBQUEsSUFDMUQsU0FBU2tDLE9BQU87QUFDZEMsY0FBUUMsSUFBSSx5QkFBeUJGLEtBQUs7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFHQSxRQUFNTyxZQUFZQSxNQUNoQix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCO0FBQUEsSUFDekIsdUJBQUMsVUFBSyxVQUFVaEMsYUFDZDtBQUFBLDZCQUFDLFNBQUc7QUFBQTtBQUFBLFFBRUY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLE9BQU94QjtBQUFBQSxZQUNQLE1BQUs7QUFBQSxZQUNMLFVBQVUsQ0FBQyxFQUFFeUQsT0FBTyxNQUFNeEQsWUFBWXdELE9BQU9DLEtBQUs7QUFBQTtBQUFBLFVBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlzRDtBQUFBLFdBTnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsU0FBRztBQUFBO0FBQUEsUUFFRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsT0FBT3JEO0FBQUFBLFlBQ1AsTUFBSztBQUFBLFlBQ0wsVUFBVSxDQUFDLEVBQUVvRCxPQUFPLE1BQU1uRCxZQUFZbUQsT0FBT0MsS0FBSztBQUFBO0FBQUEsVUFKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSXNEO0FBQUEsV0FOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBbkI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBO0FBQUEsT0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXVCQTtBQUdGLFFBQU1DLDZCQUE2QkEsTUFBTTtBQUN2QzFDLFdBQU9DLGFBQWEwQyxXQUFXLFVBQVU7QUFDekNwRCxZQUFRLElBQUk7QUFBQSxFQUNkO0FBTUEsUUFBTXFELGlCQUFpQkEsQ0FBQ3RELFVBQ3RCLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxTQUNFQTtBQUFBQSxZQUFLdUQ7QUFBQUEsTUFBSztBQUFBLE1BQ1gsdUJBQUMsWUFBTyxTQUFTLE1BQU1ILDJCQUEyQixHQUFFLHNCQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUVILHVCQUFDLGFBQVUsYUFBWSxxQkFBb0IsS0FBS2xELGFBQzlDLGlDQUFDLFlBQVMsWUFBWXFCLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBRUgsdUJBQUMsU0FDRWhDLGdCQUFNaUQ7QUFBQUEsTUFBSSxDQUFBQyxTQUNUO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQztBQUFBLFVBQ0EsTUFBTXpDO0FBQUFBLFVBQ04sUUFBUWlDO0FBQUFBLFVBQ1IsVUFBVVk7QUFBQUE7QUFBQUEsUUFKTEosS0FBS047QUFBQUEsUUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS3dCO0FBQUEsSUFFMUIsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBVUE7QUFBQSxPQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBMEJBO0FBSUYsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLGdCQUFhLFNBQVN4QyxRQUFRQSxTQUFTLE1BQU1BLFFBQVFFLFFBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkQ7QUFBQSxJQUUxRCxDQUFDRyxRQUFRLHVCQUFDLGFBQVUsZUFBZWlCLGVBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0M7QUFBQSxJQUMvQ2pCLFFBQVFzRCxlQUFldEQsSUFBSTtBQUFBLE9BTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNWLEdBOU1LRCxLQUFHO0FBQUFtRSxLQUFIbkU7QUFnTk4sZUFBZUE7QUFBRyxJQUFBbUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsIk5vdGlmaWNhdGlvbiIsIlRvZ2dsYWJsZSIsIkJsb2dGb3JtIiwiTG9naW5Gb3JtIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ0eXBlIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwiYmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJsb2dnZWRVc2VySlNPTiIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiaGFuZGxlTG9naW4iLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiYWRkQmxvZyIsImJsb2dPYmplY3QiLCJjdXJyZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsInJldHVybmVkQmxvZyIsImNyZWF0ZSIsInVwZGF0ZWRCbG9nV2l0aFVzZXIiLCJ1cGRhdGVkQmxvZ3MiLCJjb25jYXQiLCJ0aXRsZSIsImJsb2dMaWtlZCIsImxpa2VkQmxvZyIsImlkIiwiYXV0aG9yIiwidXJsIiwidXBkYXRlZEJsb2ciLCJ1cGRhdGUiLCJtYXAiLCJibG9nIiwiZXJyb3IiLCJjb25zb2xlIiwibG9nIiwiYmxvZ0RlbGV0ZWQiLCJkZWxldGVJdGVtIiwiZmlsdGVyZWRCbG9ncyIsImZpbHRlciIsImxvZ2luRm9ybSIsInRhcmdldCIsInZhbHVlIiwicmVtb3ZlVXNlckZyb21Mb2NhbFN0b3JhZ2UiLCJyZW1vdmVJdGVtIiwidXNlcklzTG9nZ2VkSW4iLCJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5pbXBvcnQgQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0Jsb2dGb3JtJ1xuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5Gb3JtJ1xuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoeyBtZXNzYWdlOiAnJywgdHlwZTogbnVsbCB9KVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IGJsb2dGb3JtUmVmID0gdXNlUmVmKG51bGwpXG5cbiAgLy8gQ2hlY2sgaWYgdXNlciBpcyBsb2dnZWQgaW4gYmVmb3JlIHJlbmRlcmluZyB0aGUgcG9zdHNcbiAgLy8gSWYgdXNlciBpcyBub3QgbG9nZ2VkIGluLCBzZXQgYmxvZ3MgdG8gbm9uZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh1c2VyKSB7XG4gICAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcbiAgICAgICAgc2V0QmxvZ3MoYmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpKVxuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0QmxvZ3MoW10pXG4gICAgfVxuICB9LCBbdXNlcl0pXG5cbiAgLy8gQ2hlY2tzLCBpZiB0aGVyZSBpcyBhIHNhdmVkIHVzZXIgaW4gbG9jYWwgc3RvcmFnZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdibG9nVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jICh1c2VybmFtZSwgcGFzc3dvcmQpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLCBwYXNzd29yZFxuICAgICAgfSlcblxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFxuICAgICAgICAnYmxvZ1VzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKVxuICAgICAgKVxuXG4gICAgICAvLyBTZXQgdXNlciBhbmQgdXBkYXRlIHN0YXRlIGluIHRoZSBBcHBcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG5cbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIHNldE1lc3NhZ2UoeyBtZXNzYWdlOiAnV3JvbmcgY3JlZGVudGlhbHMnLCB0eXBlOiAnZXJyb3InIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSh7IG1lc3NhZ2U6ICcnLCB0eXBlOiBudWxsIH0pXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGFkZEJsb2cgPSBhc3luYyAoYmxvZ09iamVjdCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBibG9nRm9ybVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKVxuXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcblxuICAgICAgLy8gV2hlbiB1c2VycyBzZW5kcyBhIGJsb2csIGl0IHdvbid0IGFkZCB0aGUgZGVsZXRlIGJ1dHRvbiB0byB0aGF0XG4gICAgICAvLyBibG9nLiBUaGlzIGNhbiBiZSBmaXhlZCBieSBhZGRpbmcgdGhlIGN1cnJlbnQgdXNlciB0byB0aGUgbmV3IGJsb2dcbiAgICAgIC8vIFdoZW4gYmxvZ3MgYXJlIHJlbmRlcmVkLCBpdCBjYW4gYWNjZXNzIHRoZSBibG9nLnVzZXIudXNlcm5hbWUgcHJvcGVydHlcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9nV2l0aFVzZXIgPSB7XG4gICAgICAgIC4uLnJldHVybmVkQmxvZyxcbiAgICAgICAgdXNlcjogdXNlciAvLyBVc2Ugc3RhdGUgaW4gdGhlIGhvb2tcbiAgICAgIH1cblxuICAgICAgLy8gRW5zdXJlIHRoZSByZXR1cm5lZCBibG9nIGhhcyB0aGUgY29tcGxldGUgdXNlciBvYmplY3RcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9ncyA9IGJsb2dzLmNvbmNhdCh1cGRhdGVkQmxvZ1dpdGhVc2VyKVxuICAgICAgc2V0QmxvZ3ModXBkYXRlZEJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKSlcblxuICAgICAgLy8gU2hvdyBzb21lIG5pY2UgQ1NTIG5vdGlmaWNhdGlvbiB0byB0aGUgdXNlclxuICAgICAgc2V0TWVzc2FnZSh7IG1lc3NhZ2U6IGBBIG5ldyBibG9nIGNhbGxlZCAke2Jsb2dPYmplY3QudGl0bGV9IGFkZGVkIWAsIHR5cGU6ICdzdWNjZXNzJyB9KVxuXG4gICAgICAvLyBNYWtlIHRoZSBub3RpZmljYXRpb24gZ28gYXdheSBhZnRlciA1IHNlY29uZHMuXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSh7IG1lc3NhZ2U6ICcnLCB0eXBlOiBudWxsIH0pXG4gICAgICB9LCA1MDAwKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0TWVzc2FnZSh7IG1lc3NhZ2U6ICdDaGVjayBpbnB1dCBmaWVsZHMnLCB0eXBlOiAnZXJyb3InIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSh7IG1lc3NhZ2U6ICcnLCB0eXBlOiBudWxsIH0pXG4gICAgICB9LCA1MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGJsb2dMaWtlZCA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGxpa2VkQmxvZyA9IHtcbiAgICAgICAgaWQ6IGJsb2dPYmplY3QuaWQsXG4gICAgICAgIHRpdGxlOiBibG9nT2JqZWN0LnRpdGxlLFxuICAgICAgICBhdXRob3I6IGJsb2dPYmplY3QuYXV0aG9yLFxuICAgICAgICB1cmw6IGJsb2dPYmplY3QudXJsLFxuICAgICAgICBsaWtlczogYmxvZ09iamVjdC5saWtlcyArIDEsXG4gICAgICAgIHVzZXI6IGJsb2dPYmplY3QudXNlci5pZFxuICAgICAgfVxuXG4gICAgICAvLyBUaGlzIGRvZXMgbm90IHJldHVybiB0aGUgdXNlciBhdHRyaWJ1dGVzLCBvbmx5IHRoZSBpZCBvZiB0aGUgdXNlclxuICAgICAgY29uc3QgdXBkYXRlZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS51cGRhdGUobGlrZWRCbG9nKVxuXG4gICAgICAvLyBUYWtlIHRoZSB1c2VyIGZyb20gdGhlIG9yaWdpbmFsIHJlcXVlc3QgYW5kIHVwZGF0ZSB0aGUgcmVzcG9uc2VcbiAgICAgIC8vIHdpdGggdGhlIHVzZXIuXG4gICAgICBjb25zdCB1cGRhdGVkQmxvZ1dpdGhVc2VyID0ge1xuICAgICAgICAuLi51cGRhdGVkQmxvZyxcbiAgICAgICAgdXNlcjogYmxvZ09iamVjdC51c2VyXG4gICAgICB9XG5cbiAgICAgIC8vIElmIHRoZSBpZCBvZiB0aGUgYmxvZyBpcyBub3QgdGhlIHNhbWUgYXMgdGhlIHVwZGF0ZSBpZFxuICAgICAgLy8gUmV0dXJuIHRoZSBvcmlnaW5hbCBibG9nLiBJbiBvdGhlciB3b3JkcywgZG8gbm90IGNoYW5nZSBibG9nc1xuICAgICAgLy8gdGhhdCBJRHMgYXJlIG5vdCB0aGUgc2FtZSBhcyB0aGUgdXBkYXRlZCBibG9nLlxuICAgICAgLy8gSWYgdGhlIHVwZGF0ZWQgYmxvZyBoYXMgYW4gaWQgdGhhdCBtYXRjaGVzIGEgcHJldmlvdXMgYmxvZ1xuICAgICAgLy8gVXBkYXRlIGl0IGFuZCByZXR1cm4gdGhlIHVwZGF0ZWRCbG9nIGFuZCByZXBsYWNlIHdpdGggc2V0QmxvZ3NcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9ncyA9IGJsb2dzLm1hcChibG9nID0+IGJsb2cuaWQgIT09IHVwZGF0ZWRCbG9nLmlkID8gYmxvZyA6IHVwZGF0ZWRCbG9nV2l0aFVzZXIpXG4gICAgICBzZXRCbG9ncyh1cGRhdGVkQmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpKVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3IgbGlraW5nIGJsb2c6ICcsIGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGJsb2dEZWxldGVkID0gYXN5bmMgKGlkKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUl0ZW0oaWQpXG4gICAgICBjb25zdCBmaWx0ZXJlZEJsb2dzID0gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gaWQpXG4gICAgICBzZXRCbG9ncyhmaWx0ZXJlZEJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5sb2coJ0Vycm9yIGRlbGV0aW5nIGJsb2c6ICcsIGVycm9yKVxuICAgIH1cbiAgfVxuXG4gIC8vIFBhc3N3b3JkIGFuZCB1c2VybmFtZSBzdGF0ZVxuICBjb25zdCBsb2dpbkZvcm0gPSAoKSA9PiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5Mb2cgaW4gdG8gYXBwbGljYXRpb248L2gyPlxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB1c2VybmFtZVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgbmFtZT1cInVzZXJuYW1lXCJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICBwYXNzd29yZFxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPkxvZ2luPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC9kaXY+XG4gIClcblxuICBjb25zdCByZW1vdmVVc2VyRnJvbUxvY2FsU3RvcmFnZSA9ICgpID0+IHtcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2Jsb2dVc2VyJylcbiAgICBzZXRVc2VyKG51bGwpXG4gIH1cblxuICAvLyBQYXNzaW5nIHRoZSBmdW5jdGlvbnMgdG8gdGhlIEJsb2cgY29tcG9uZW50cyBiZWNhdXNlIGJsb2dzIGFyZSBiZWluZyBtYW5hZ2VkXG4gIC8vIHdpdGggdGhlIGJsb2dzIHN0YXRlIGhvb2suIElmIHRoZXkgd291bGQgYmUgZGVmaW5lZCBpbiB0aGUgQmxvZyBjb21wb25lbnRcbiAgLy8gdGhlIGNvbXBvbmVudCB3b3VsZCBiZSBuZWVkZWQgdG8gYmUgZG9uZSBpbiBhIGRpZmZlcmVudCB3YXkuXG4gIC8vIEluIHRoaXMgY2FzZSwgaXQgaXMgYmV0dGVyIHRoYXQgdGhlIGJsb2dzIHN0YXkgdGhpcyB3YXkuXG4gIGNvbnN0IHVzZXJJc0xvZ2dlZEluID0gKHVzZXIpID0+IChcbiAgICA8ZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAge3VzZXIubmFtZX0gbG9nZ2VkIGluJm5ic3A7XG4gICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gcmVtb3ZlVXNlckZyb21Mb2NhbFN0b3JhZ2UoKX0+XG4gICAgICAgIExvZ291dFxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJyLz5cblxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cIkNyZWF0ZSBhIG5ldyBibG9nXCIgcmVmPXtibG9nRm9ybVJlZn0+XG4gICAgICAgIDxCbG9nRm9ybSBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxuICAgICAgPC9Ub2dnbGFibGU+XG5cbiAgICAgIDxici8+XG5cbiAgICAgIDxkaXY+XG4gICAgICAgIHtibG9ncy5tYXAoYmxvZyA9PlxuICAgICAgICAgIDxCbG9nXG4gICAgICAgICAgICBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgICBibG9nPXtibG9nfVxuICAgICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICAgIG9uTGlrZT17YmxvZ0xpa2VkfVxuICAgICAgICAgICAgb25EZWxldGU9e2Jsb2dEZWxldGVkfVxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIC8vIEFkZCByZWYgaW4gdGhlIGNyZWF0ZUJsb2cgdG8gaGlkZSBpdCBhZnRlciBibG9nIGNyZWF0aW9uXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5CbG9nczwvaDI+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2UubWVzc2FnZX0gdHlwZT17bWVzc2FnZS50eXBlfSAvPlxuXG4gICAgICB7IXVzZXIgJiYgPExvZ2luRm9ybSBsb2dpbkZ1bmN0aW9uPXtoYW5kbGVMb2dpbn0gLz59XG4gICAgICB7dXNlciAmJiB1c2VySXNMb2dnZWRJbih1c2VyKX1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6IkM6L1VzZXJzL3NhbXVrL0RvY3VtZW50cy9PaGplbG1vaW50aS9XZWIvRnVsbFN0YWNrT3Blbi9vc2E1L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=