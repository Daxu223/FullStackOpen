import axios from "/node_modules/.vite/deps/axios.js?v=8a83d9c8"
const baseUrl = '/api/login'

const login = async credentials => {
  // Returns a promise object, so await is needed to resolve the promise.
  const response = await axios.post(baseUrl, credentials)

  // TODO: If token expires, log user out.
  return response.data
}

export default { login }